import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Client } from 'src/app/classes/client/client';

@Injectable({
  providedIn: 'root'
})
export class TableService {

  constructor(private http: HttpClient) { }

  getPagedUsers(page: number){
    return this.http.get(environment.apiUrl+`api/clienti?page=${page}&size=20&sort=id,ASC`)
  }

  getClientType(){
    return this.http.get<string[]>(environment.apiUrl+`api/clienti/tipicliente`)
  }

  addClient(client: Client){
    return this.http.post(environment.apiUrl+'api/clienti', client)
  }

  deleteClient(client: Client){
    return this.http.delete(environment.apiUrl+'api/clienti/'+client.id)
  }

}
