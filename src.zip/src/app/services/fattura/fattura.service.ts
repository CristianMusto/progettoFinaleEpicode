import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Client } from 'src/app/classes/client/client';
import { Fattura } from 'src/app/classes/fattura/fattura';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class FatturaService {

  constructor(private http : HttpClient) { }

  getFattureByClient(id: number, page: number){
    return this.http.get<Fattura[]>(environment.apiUrl+'api/fatture/cliente/'+id+'/page/'+page)
  }
}
