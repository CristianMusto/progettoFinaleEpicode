export interface IuserLog {
    username: string,
    password: string,
}
