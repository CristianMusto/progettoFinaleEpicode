import { LoginGuard } from './guards/login/login.guard';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home/home.component';
import { LoginComponent } from './components/login/login/login.component';
import { TableComponent } from './components/users/table/table.component';
import { AddUserComponent } from './components/users/add-user/add-user.component';
import { SignupComponent } from './components/singup/signup/signup.component';
import { SignupGuard } from './guards/signup/signup.guard';
import { FatturaComponent } from './components/fattura/fattura/fattura.component';

const routes: Routes = [
  { 
    path: '', 
    component: HomeComponent 
  },
  { 
    path: 'login', 
    component: LoginComponent 
  },
  { 
    path: 'table', 
    component: TableComponent, 
    canActivate: [LoginGuard]
  },
  {
    path:"table/page/:page",
    component: TableComponent
  },
  {
    path:"addUser",
    component: AddUserComponent
  },
  {
    path:"signup",
    component: SignupComponent,
    canActivate: [SignupGuard]
  },
  {
    path:"fattura/cliente/:id/page/:page",
    component: FatturaComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
