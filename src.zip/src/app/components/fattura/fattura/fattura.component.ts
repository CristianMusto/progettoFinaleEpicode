import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Client } from 'src/app/classes/client/client';
import { Fattura } from 'src/app/classes/fattura/fattura';
import { FatturaService } from 'src/app/services/fattura/fattura.service';

@Component({
  selector: 'app-fattura',
  templateUrl: './fattura.component.html',
  styleUrls: ['./fattura.component.css']
})
export class FatturaComponent implements OnInit {

  fatture: Fattura[] = [];
  totalElements!: number;
  size!: number;
  numberOfPages!: number;
  pageNumbers: number[] = [];

  constructor(private fatturaService: FatturaService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.getFattureByClient()
  }

  getFattureByClient(){
    this.route.params.subscribe(params => {
      console.log(params['id']);
      this.fatturaService.getFattureByClient(params['id'], params['page']).subscribe((data:any) => {
        console.log(data.content);
        this.fatture = data.content;

      })
    })
  }

}
