import { Component, OnInit } from '@angular/core';
import { Client } from 'src/app/classes/client/client';
import { ComuniService } from 'src/app/services/comuni/comuni.service';
import { TableService } from 'src/app/services/users/table.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  client: Client = new Client();
  clientType: string[] = [];
  comuni: string[] = [];

  constructor(private clientService: TableService, private comuniService : ComuniService) { }

  ngOnInit(): void {
    this.getClientType()
    this.getComuni()
  }

  getClientType(){
    this.clientService.getClientType().subscribe(data => {
      console.log(data);
      this.clientType = data;
    })
  }

  getComuni(){
    this.comuniService.getComuni().subscribe(data => {
      this.comuni = data;
    })
  }

  addClient(client: Client){
    this.clientService.addClient(client).subscribe(data => console.log(data))
  }



}
