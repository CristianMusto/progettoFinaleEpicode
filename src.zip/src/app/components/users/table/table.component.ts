import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Client } from 'src/app/classes/client/client';
import { TableService } from 'src/app/services/users/table.service';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {

  clients: Client[] = [];
  totalElements!: number;
  size!: number;
  numberOfPages!: number;
  pageNumbers: number[] = [];

  constructor(private route: ActivatedRoute, private clientService: TableService, private router: Router) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      
      this.clientService.getPagedUsers(params["page"]).subscribe((clients:any) => {
       
        this.clients = clients.content

        this.totalElements = clients.totalElements
        this.size = clients.size
        this.numberOfPages = Math.round(clients.totalElements / clients.size)


        for(let i = 0; i <= this.numberOfPages; i++){
          console.log(i);
          this.pageNumbers.push(i);
        }
      });

    })
  }

  openAdd(e:any){
    e.preventDefault();
    this.router.navigate(['addUser'])
  }

  removeClient(client:Client) {
    this.clientService.deleteClient(client).subscribe(data => {
      console.log(data);
    })
  }

  fattura(client:Client) {
    this.router.navigate(['fattura/cliente/'+client.id])
  }

}
