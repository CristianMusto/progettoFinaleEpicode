import { Fattura } from './fattura';

describe('Fattura', () => {
  it('should create an instance', () => {
    expect(new Fattura()).toBeTruthy();
  });
});
