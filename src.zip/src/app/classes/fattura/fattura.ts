import { IClient } from "src/app/interfaces/client/iclient"
import { IStatoFattura } from "src/app/interfaces/fattura/ifattura"

export class Fattura {
    id!: number;
    data!: string;
    numero!: number;
    anno!: number;
    importo!: string;
    stato!: IStatoFattura;
    cliente!: IClient;
}
