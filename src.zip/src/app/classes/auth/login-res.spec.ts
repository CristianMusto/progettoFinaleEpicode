import { LoginRes } from './login-res';

describe('LoginRes', () => {
  it('should create an instance', () => {
    expect(new LoginRes()).toBeTruthy();
  });
});
