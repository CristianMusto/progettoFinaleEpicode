export class AdminLog {
    username: string = 'admin';
    password: string = '111111';
}
