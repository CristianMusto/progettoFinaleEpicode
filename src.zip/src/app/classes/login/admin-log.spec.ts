import { AdminLog } from './admin-log';

describe('AdminLog', () => {
  it('should create an instance', () => {
    expect(new AdminLog()).toBeTruthy();
  });
});
