import { UserLog } from './user-log';

describe('UserLog', () => {
  it('should create an instance', () => {
    expect(new UserLog()).toBeTruthy();
  });
});
