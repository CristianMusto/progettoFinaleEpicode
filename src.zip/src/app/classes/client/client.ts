import { IClient, IComuni, IIndirizzoS, IProvincia } from "src/app/interfaces/client/iclient";

export class Client implements IClient{
    id!: number;
    ragioneSociale!: string;
    partitaIva!: string;
    tipoCliente!: string;
    email!: string;
    pec!: string;
    telefono!: string;
    nomeContatto!: string;
    cognomeContatto!: string;
    telefonoContatto!: string;
    emailContatto!: string;
    indirizzoSedeOperativa!: IndirizzoS;
    indirizzoSedeLegale!: IndirizzoS;
    dataInserimento!: string;
    dataUltimoContatto!: string;
    fatturatoAnnuale!: number;
}

export class IndirizzoS implements IIndirizzoS{
    id!: number;
    via!: string;
    civico!: string;
    cap!: string;
    localita!: string;
    comune!: Comuni;
} 

export class Comuni implements IComuni {
    id!: number;
    nome!: string;
    provincia!: Provincia;
}

export class Provincia implements IProvincia {
    id!: number;
    nome!: string;
    sigla!: string;
}